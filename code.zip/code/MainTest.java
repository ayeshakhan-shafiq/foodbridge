import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/*
 * JUnit 5 tests for FoodBridge.
 * Each test starts with empty data (reset) and checks one rule from our requirements.
 */
public class MainTest {

    @BeforeEach
    void setUp() {
        Main.reset();
    }

    // FR-4: the food that expires first is always on top of the Min-Heap
    @Test
    void heapKeepsSoonestExpiryOnTop() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Pulao", 10, 12);
        Main.addFood(d.id, "Biryani", 10, 2);
        Main.addFood(d.id, "Karahi", 10, 4);
        assertEquals("Biryani", Main.foodHeap.removeMin().name);
        assertEquals("Karahi", Main.foodHeap.removeMin().name);
        assertEquals("Pulao", Main.foodHeap.removeMin().name);
        assertTrue(Main.foodHeap.isEmpty());
    }

    // FR-5: the most urgent organization is served first
    @Test
    void mostUrgentOrganizationServedFirst() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Rice", 30, 5);
        Main.addOrganization("Low", 100, 50, 2);
        Main.addOrganization("High", 100, 50, 5);
        Main.runAllocation();
        assertEquals("High", Main.allocationLog.get(0).orgName);
        assertEquals(30, Main.orgs.get("O2").received);
        assertEquals(0, Main.orgs.get("O1").received);
    }

    // FR-5: same urgency -> more people in need goes first
    @Test
    void tieGoesToMorePeopleInNeed() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Rice", 10, 5);
        Main.addOrganization("Fewer people", 100, 20, 4);
        Main.addOrganization("More people", 100, 60, 4);
        Main.runAllocation();
        assertEquals("More people", Main.allocationLog.get(0).orgName);
    }

    // FR-6: give = min(food, storage space, need)  ->  min(50, 20, 60) = 20
    @Test
    void giveIsSmallestOfFoodSpaceAndNeed() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Biryani", 50, 10);
        Main.Organization o = Main.addOrganization("Small Shelter", 20, 60, 5);
        Main.runAllocation();
        assertEquals(20, Main.allocationLog.get(0).quantity);
        assertEquals(0, o.spaceLeft());       // never more than its storage
        assertEquals(40, o.need);             // still needs 40
    }

    // FR-7: leftover food stays in the heap for the next organization
    @Test
    void leftoverGoesToNextOrganization() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Biryani", 50, 10);
        Main.addOrganization("Small Shelter", 20, 60, 5);
        Main.addOrganization("Big Kitchen", 100, 30, 2);
        Main.runAllocation();
        assertEquals(20, Main.orgs.get("O1").received);
        assertEquals(30, Main.orgs.get("O2").received);
        assertEquals("FINISHED", Main.foods.get("F1").status);
    }

    // FR-9: expired food is removed and never given out
    @Test
    void expiredFoodIsNeverGiven() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Salad", 30, -1);     // already expired
        Main.addFood(d.id, "Rice", 30, 48);
        Main.addOrganization("Shelter", 100, 70, 4);
        Main.runAllocation();
        assertEquals(1, Main.allocationLog.size());
        assertEquals("Rice", Main.allocationLog.get(0).foodName);
        assertEquals("EXPIRED", Main.foods.get("F1").status);
        assertEquals(30, Main.totalExpired);
    }

    // FR-2: any record is found by its ID through the HashMaps
    @Test
    void findRecordsById() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Rice", 30, 5);
        Main.addOrganization("Shelter", 100, 70, 4);
        assertEquals("Test Kitchen", Main.donors.get("D1").name);
        assertEquals("Rice", Main.foods.get("F1").name);
        assertEquals("Shelter", Main.orgs.get("O1").name);
        assertNull(Main.foods.get("F9"));
    }

    // FR-3: wrong input is rejected
    @Test
    void wrongInputIsRejected() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        assertNull(Main.addOrganization("Bad urgency", 100, 50, 7));
        assertNull(Main.addOrganization("Bad capacity", 0, 50, 3));
        assertNull(Main.addFood(d.id, "Soup", -5, 3));
        assertNull(Main.addFood("D9", "Soup", 10, 3));
        assertTrue(Main.orgs.isEmpty());
        assertTrue(Main.foods.isEmpty());
    }

    // FR-1: update keeps the heap and the totals correct
    @Test
    void updateFoodKeepsHeapAndTotalsCorrect() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Soup", 20, 10);
        Main.addFood(d.id, "Rice", 20, 5);
        assertTrue(Main.updateFood("F1", "Soup", 35, 1));   // now expires first
        Main.removeExpired();
        assertEquals("Soup", Main.foodHeap.peek().name);
        assertEquals(35, Main.foodHeap.peek().quantity);
        assertEquals(55, Main.totalDonated);
        assertFalse(Main.updateOrganization("O1", "Nobody", 10, 10, 3));   // not found
    }

    // FR-10: every portion donated is given, available, expired or deleted
    @Test
    void totalsAlwaysAddUp() {
        Main.Donor d = Main.addDonor("Test Kitchen", "Restaurant");
        Main.addFood(d.id, "Salad", 30, -1);
        Main.addFood(d.id, "Rolls", 30, 1);
        Main.addFood(d.id, "Rice", 30, 48);
        Main.addOrganization("Shelter", 100, 40, 4);
        Main.runAllocation();
        int sum = Main.totalGiven + Main.portionsAvailable() + Main.totalExpired + Main.totalDeleted;
        assertEquals(Main.totalDonated, sum);
        assertEquals(40, Main.totalGiven);
    }

    // FR-11 (TC-11): data is saved to the SQLite database and loaded back the same
    // (skipped if the SQLite JDBC driver is not on the classpath)
    @Test
    void databaseSavesAndLoadsEverything() throws Exception {
        java.io.File file = java.io.File.createTempFile("foodbridge-test", ".db");
        file.deleteOnExit();
        if (!Database.open(file.getPath())) return;          // no driver: nothing to test
        Main.Donor d = Main.addDonor("Karachi Kitchen House", "Restaurant");
        Main.addFood(d.id, "Biryani", 50, 10);
        Main.addOrganization("Small Shelter", 20, 60, 5);
        Main.runAllocation();
        Database.save();

        Main.reset();                                         // forget everything in memory
        assertTrue(Database.load());                          // ...and read it back
        assertEquals(1, Main.donors.size());
        assertEquals(30, Main.foods.get("F1").quantity);
        assertEquals(20, Main.orgs.get("O1").received);
        assertEquals(1, Main.allocationLog.size());
        assertEquals(20, Main.totalGiven);
        assertEquals("F1", Main.foodHeap.peek().id);          // the Min-Heap is rebuilt too
        Database.close();
    }
}
