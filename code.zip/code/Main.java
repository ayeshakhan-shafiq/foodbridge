import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Scanner;

/*
 * FoodBridge: An Expiry-Aware Surplus Food Donation Allocator
 *
 * Idea: Donors give extra food. Organizations (shelters) need food.
 *  - The food that will EXPIRE FIRST is given out first      -> Min-Heap
 *  - The MOST URGENT organization is served first            -> Priority Queue
 *  - Donors, food and organizations are found quickly by ID  -> HashMap
 *
 * Time is counted in hours. "now" starts at hour 0.
 *
 * Notation: n = number of food items, m = number of organizations,
 *           d = number of donors, e = number of expired items.
 *
 * COMPLEXITY SUMMARY
 *   MinHeap peek ................. O(1)
 *   MinHeap insert / removeMin ... O(log n)
 *   HashMap put / get / remove ... O(1) average
 *   PriorityQueue add / poll ..... O(log m)
 *   removeExpired ................ O(e log n)   (each item is removed once)
 *   runAllocation ................ O((n + m) log(n + m))
 *   findById ..................... O(1)
 *   deleteById (org / food) ...... O(1)   (food: O(log n) later, lazily)
 *   deleteById (donor) ........... O(n)   (checks the donor's food)
 *   updateById (food) ............ O(log n) (old copy removed lazily, new copy inserted)
 *   updateById (donor / org) ..... O(1)
 *   Space ........................ O(n + m + d)
 *
 * DATABASE (back end): Database.java saves everything in SQLite (foodbridge.db) with JDBC
 * after every menu choice, and loads it again when the program starts.
 * Run:  javac -cp lib/sqlite-jdbc-3.41.2.2.jar *.java
 *       java  -cp ".;lib/sqlite-jdbc-3.41.2.2.jar" Main      (Windows; use ":" on Mac/Linux)
 */
public class Main {

    // =====================================================
    // PART 1: THE DATA (what we store)
    // =====================================================

    // A donor: restaurant, supermarket or event hall
    static class Donor {
        String id;
        String name;
        String type;

        Donor(String id, String name, String type) {
            this.id = id;
            this.name = name;
            this.type = type;
        }

        public String toString() {
            return id + " " + name + " (" + type + ")";
        }
    }

    // A food item that a donor gives
    static class FoodItem {
        String id;
        String name;
        int quantity;        // portions left
        int expiryHour;      // the hour when this food expires
        String donorId;
        String status = "AVAILABLE";   // AVAILABLE, FINISHED, EXPIRED or REMOVED

        FoodItem(String id, String name, int quantity, int expiryHour, String donorId) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.expiryHour = expiryHour;
            this.donorId = donorId;
        }

        public String toString() {
            return id + " " + name + " x" + quantity + " (expires at hour " + expiryHour
                    + ", donor " + donorId + ", " + status + ")";
        }
    }

    // An organization (shelter / welfare group) that needs food
    static class Organization {
        String id;
        String name;
        int capacity;     // how many portions it can store in total
        int received = 0; // portions it has already received
        int need;         // people still without food (1 portion = 1 person)
        int urgency;      // 1 = low ... 5 = very urgent

        Organization(String id, String name, int capacity, int need, int urgency) {
            this.id = id;
            this.name = name;
            this.capacity = capacity;
            this.need = need;
            this.urgency = urgency;
        }

        int spaceLeft() {
            return capacity - received;
        }

        public String toString() {
            return id + " " + name + " (urgency " + urgency + ", need " + need
                    + ", space left " + spaceLeft() + ")";
        }
    }

    // One allocation: which food went to which organization, and how much
    static class Allocation {
        String id;
        String foodId;
        String foodName;
        String orgId;
        String orgName;
        int quantity;
        int hour;          // the hour when it was given

        // used when an allocation is loaded back from the database
        Allocation(String id, String foodId, String foodName, String orgId, String orgName, int quantity, int hour) {
            this.id = id;
            this.foodId = foodId;
            this.foodName = foodName;
            this.orgId = orgId;
            this.orgName = orgName;
            this.quantity = quantity;
            this.hour = hour;
        }

        Allocation(String id, FoodItem f, Organization o, int quantity, int hour) {
            this.id = id;
            this.foodId = f.id;
            this.foodName = f.name;
            this.orgId = o.id;
            this.orgName = o.name;
            this.quantity = quantity;
            this.hour = hour;
        }

        public String toString() {
            return id + ": " + quantity + " x " + foodName + " (" + foodId + ") -> " + orgName + " (" + orgId + ") at hour " + hour;
        }
    }

    // =====================================================
    // PART 2: MIN-HEAP (we write this ourselves)
    // The food that expires FIRST is always at position 0 (the top).
    // For position i:  parent = (i-1)/2,  left child = 2i+1,  right child = 2i+2
    // =====================================================
    static class MinHeap {
        ArrayList<FoodItem> list = new ArrayList<>();

        boolean isEmpty() {
            return list.isEmpty();
        }

        // Look at the top item without removing it. Speed: O(1)
        FoodItem peek() {
            return list.get(0);
        }

        // Add at the END, then move it UP while it expires earlier than its parent.
        // Speed: O(log n)
        void insert(FoodItem item) {
            list.add(item);
            int i = list.size() - 1;
            while (i > 0) {
                int parent = (i - 1) / 2;
                if (list.get(i).expiryHour < list.get(parent).expiryHour) {
                    swap(i, parent);
                    i = parent;
                } else {
                    break;
                }
            }
        }

        // Remove the top item: put the LAST item on top, then move it DOWN.
        // Speed: O(log n)
        FoodItem removeMin() {
            FoodItem top = list.get(0);
            FoodItem last = list.remove(list.size() - 1);
            if (!list.isEmpty()) {
                list.set(0, last);
                int i = 0;
                while (true) {
                    int left = 2 * i + 1;
                    int right = 2 * i + 2;
                    int smallest = i;
                    if (left < list.size() && list.get(left).expiryHour < list.get(smallest).expiryHour) {
                        smallest = left;
                    }
                    if (right < list.size() && list.get(right).expiryHour < list.get(smallest).expiryHour) {
                        smallest = right;
                    }
                    if (smallest == i) break;     // heap rule is true, stop
                    swap(i, smallest);
                    i = smallest;
                }
            }
            return top;
        }

        void swap(int a, int b) {
            FoodItem temp = list.get(a);
            list.set(a, list.get(b));
            list.set(b, temp);
        }
    }

    // =====================================================
    // PART 3: THE SYSTEM (all data lives here)
    // =====================================================

    // HashMaps: find anything by its ID quickly. Speed: O(1) on average
    static HashMap<String, Donor> donors = new HashMap<>();
    static HashMap<String, FoodItem> foods = new HashMap<>();
    static HashMap<String, Organization> orgs = new HashMap<>();

    static MinHeap foodHeap = new MinHeap();                      // food, soonest expiry on top
    static ArrayList<Allocation> allocationLog = new ArrayList<>();   // who got what
    static ArrayList<FoodItem> expiredFood = new ArrayList<>();   // wasted food

    static int now = 0;                                           // current hour
    static int donorCount = 0, foodCount = 0, orgCount = 0;       // used to make IDs

    // Totals for the report (all in portions)
    static int totalDonated = 0, totalGiven = 0, totalExpired = 0, totalDeleted = 0;
    static Scanner sc = new Scanner(System.in);

    // Start again with empty data (used by the JUnit tests)
    static void reset() {
        donors.clear();
        foods.clear();
        orgs.clear();
        foodHeap = new MinHeap();
        allocationLog.clear();
        expiredFood.clear();
        now = 0;
        donorCount = 0; foodCount = 0; orgCount = 0;
        totalDonated = 0; totalGiven = 0; totalExpired = 0; totalDeleted = 0;
    }

    // ---------- Adding data ----------

    static Donor addDonor(String name, String type) {
        donorCount++;
        Donor d = new Donor("D" + donorCount, name, type);
        donors.put(d.id, d);                 // O(1)
        return d;
    }

    static FoodItem addFood(String donorId, String name, int quantity, int hoursUntilExpiry) {
        if (!donors.containsKey(donorId)) {
            System.out.println("Donor " + donorId + " not found. Add the donor first.");
            return null;
        }
        if (quantity <= 0) {
            System.out.println("Portions must be more than 0.");
            return null;
        }
        foodCount++;
        FoodItem f = new FoodItem("F" + foodCount, name, quantity, now + hoursUntilExpiry, donorId);
        foods.put(f.id, f);                  // O(1)
        foodHeap.insert(f);                  // O(log n)
        totalDonated = totalDonated + quantity;
        return f;
    }

    static Organization addOrganization(String name, int capacity, int need, int urgency) {
        if (capacity <= 0 || need < 0) {
            System.out.println("Capacity must be more than 0 and need cannot be negative.");
            return null;
        }
        if (urgency < 1 || urgency > 5) {
            System.out.println("Urgency must be from 1 to 5.");
            return null;
        }
        orgCount++;
        Organization o = new Organization("O" + orgCount, name, capacity, need, urgency);
        orgs.put(o.id, o);                   // O(1)
        return o;
    }

    // ---------- Remove expired and deleted food ----------
    // The food that expires first is always on top of the heap,
    // so we only look at the top and stop at the first food that is still fresh.
    // Food deleted by the user is marked REMOVED (lazy deletion) and is thrown
    // away here when it reaches the top.
    // Speed: O(e log n) - every item is removed at most once.
    static void removeExpired() {
        while (!foodHeap.isEmpty()) {
            FoodItem top = foodHeap.peek();
            if (top.status.equals("REMOVED")) {
                foodHeap.removeMin();                 // deleted by the user, just discard
            } else if (top.expiryHour <= now) {
                foodHeap.removeMin();
                top.status = "EXPIRED";
                expiredFood.add(top);
                totalExpired = totalExpired + top.quantity;
            } else {
                break;                                // first fresh food, stop
            }
        }
    }

    // ---------- THE MAIN ALGORITHM: allocation ----------
    // Speed: O((n + m) log(n + m)).
    // Every loop gives min(food, space, need), so each round either finishes a food
    // item (at most n times) or removes an organization for good (at most m times).
    // Each round costs O(log n + log m).
    static void runAllocation() {
        // Priority Queue of organizations: most urgent first.
        // If urgency is the same, the one with more people in need goes first.
        PriorityQueue<Organization> queue = new PriorityQueue<>((a, b) -> {
            if (a.urgency != b.urgency) return b.urgency - a.urgency;
            return b.need - a.need;
        });

        // Put in every organization that still needs food and has space. O(m log m)
        for (Organization o : orgs.values()) {
            if (o.need > 0 && o.spaceLeft() > 0) {
                queue.add(o);
            }
        }

        while (!queue.isEmpty()) {
            removeExpired();                       // 1. throw away expired / deleted food
            if (foodHeap.isEmpty()) break;         // no food left, stop

            FoodItem food = foodHeap.peek();       // 2. food that expires soonest
            Organization org = queue.poll();       // 3. most urgent organization

            // 4. Give the SMALLEST of: food available, space in storage, people in need
            int give = Math.min(food.quantity, Math.min(org.spaceLeft(), org.need));

            food.quantity = food.quantity - give;
            org.received = org.received + give;
            org.need = org.need - give;
            totalGiven = totalGiven + give;
            allocationLog.add(new Allocation("A" + (allocationLog.size() + 1), food, org, give, now));

            // 5. If the food is finished, remove it from the heap.
            //    If not, the leftover stays in the heap for the next organization.
            if (food.quantity == 0) {
                foodHeap.removeMin();
                food.status = "FINISHED";
            }

            // 6. If the organization still needs food and has space, put it back in the queue
            if (org.need > 0 && org.spaceLeft() > 0) {
                queue.add(org);
            }
        }
        System.out.println("Allocation finished. Choose 5 to see the report.");
    }

    // ---------- Report ----------
    static int portionsAvailable() {
        int sum = 0;
        for (FoodItem f : foods.values()) {
            if (f.status.equals("AVAILABLE")) sum = sum + f.quantity;
        }
        return sum;
    }

    static void printReport() {
        removeExpired();                         // so the report is up to date
        System.out.println("\n===== ALLOCATION REPORT (hour " + now + ") =====");

        System.out.println("Who got what:");
        if (allocationLog.isEmpty()) System.out.println("  (nothing yet)");
        for (Allocation a : allocationLog) System.out.println("  " + a);

        System.out.println("Organizations:");
        if (orgs.isEmpty()) System.out.println("  (none)");
        for (Organization o : orgs.values()) {
            System.out.println("  " + o.name + ": received " + o.received + ", still in need "
                    + o.need + ", space left " + o.spaceLeft());
        }

        System.out.println("Food still not given out:");
        boolean found = false;
        for (FoodItem f : foods.values()) {
            if (f.status.equals("AVAILABLE")) {
                System.out.println("  " + f);
                found = true;
            }
        }
        if (!found) System.out.println("  (none)");

        System.out.println("Expired (wasted) food:");
        if (expiredFood.isEmpty()) System.out.println("  (none)");
        for (FoodItem f : expiredFood) System.out.println("  " + f);

        // Every portion donated is either given, still available, expired or deleted
        System.out.println("Totals (portions):");
        System.out.println("  Donated " + totalDonated + " = Given " + totalGiven + " + Available " + portionsAvailable()
                + " + Expired " + totalExpired + " + Deleted " + totalDeleted);
        System.out.println("=============================");
    }

    // ---------- Find by ID (HashMap) ----------
    // Speed: O(1) on average
    static void findById() {
        System.out.print("Type an ID (like D1, F2 or O1): ");
        String id = sc.nextLine().trim().toUpperCase();
        Object result = null;
        if (id.startsWith("D")) result = donors.get(id);
        else if (id.startsWith("F")) result = foods.get(id);
        else if (id.startsWith("O")) result = orgs.get(id);
        System.out.println(result == null ? "Not found." : result.toString());
    }

    // ---------- Delete by ID (HashMap) ----------
    // Organization: O(1).
    // Food: O(1) now (lazy deletion). It is only marked REMOVED, and the heap
    //       throws it away later when it reaches the top, O(log n).
    //       (Deleting from the middle of a heap directly would need an O(n) search.)
    // Donor: O(n), because we check that the donor has no available food.
    static void deleteById() {
        System.out.print("Type an ID to delete (like D1, F2 or O1): ");
        String id = sc.nextLine().trim().toUpperCase();

        if (id.startsWith("D") && donors.containsKey(id)) {
            // A donor cannot be deleted while its food is still available
            for (FoodItem f : foods.values()) {
                if (f.donorId.equals(id) && f.status.equals("AVAILABLE")) {
                    System.out.println("Cannot delete: " + id + " still has available food ("
                            + f.id + "). Delete that food first.");
                    return;
                }
            }
            donors.remove(id);
            System.out.println("Donor " + id + " deleted.");

        } else if (id.startsWith("F") && foods.containsKey(id)) {
            FoodItem f = foods.get(id);
            if (f.status.equals("AVAILABLE")) {
                f.status = "REMOVED";     // lazy deletion: the heap discards it later
                totalDeleted = totalDeleted + f.quantity;
            }
            foods.remove(id);
            System.out.println("Food " + id + " deleted.");

        } else if (id.startsWith("O") && orgs.containsKey(id)) {
            orgs.remove(id);              // the queue is rebuilt on every run, so nothing else to clean
            System.out.println("Organization " + id + " deleted.");

        } else {
            System.out.println("Not found.");
        }
    }

    // ---------- Update by ID ----------
    // Donor and organization: change the values in place, O(1).
    // Food: its expiry may change, which would break the heap order. So the old copy is
    //       marked REMOVED (thrown away later, like a delete) and a new copy with the
    //       same ID is inserted. Speed: O(log n).
    static boolean updateDonor(String id, String name, String type) {
        Donor d = donors.get(id);
        if (d == null) { System.out.println("Not found."); return false; }
        d.name = name;
        d.type = type;
        return true;
    }

    static boolean updateFood(String id, String name, int quantity, int hoursUntilExpiry) {
        FoodItem old = foods.get(id);
        if (old == null) { System.out.println("Not found."); return false; }
        if (!old.status.equals("AVAILABLE")) {
            System.out.println("Only available food can be changed. This food is " + old.status + ".");
            return false;
        }
        if (quantity <= 0) { System.out.println("Portions must be more than 0."); return false; }
        old.status = "REMOVED";                                  // lazy: the heap throws it away later
        FoodItem f = new FoodItem(id, name, quantity, now + hoursUntilExpiry, old.donorId);
        foods.put(id, f);                                        // O(1)
        foodHeap.insert(f);                                      // O(log n)
        totalDonated = totalDonated + (quantity - old.quantity);
        return true;
    }

    static boolean updateOrganization(String id, String name, int capacity, int need, int urgency) {
        Organization o = orgs.get(id);
        if (o == null) { System.out.println("Not found."); return false; }
        if (capacity < o.received) {
            System.out.println("Capacity cannot be less than what it already received (" + o.received + ").");
            return false;
        }
        if (need < 0) { System.out.println("Need cannot be negative."); return false; }
        if (urgency < 1 || urgency > 5) { System.out.println("Urgency must be from 1 to 5."); return false; }
        o.name = name;
        o.capacity = capacity;
        o.need = need;
        o.urgency = urgency;
        return true;
    }

    static void updateById() {
        System.out.print("Type an ID to update (like D1, F2 or O1): ");
        String id = sc.nextLine().trim().toUpperCase();
        if (id.startsWith("D") && donors.containsKey(id)) {
            System.out.print("New name: ");
            String name = sc.nextLine();
            System.out.print("New type (Restaurant / Supermarket / Event Hall): ");
            String type = sc.nextLine();
            if (updateDonor(id, name, type)) System.out.println("Updated: " + donors.get(id));
        } else if (id.startsWith("F") && foods.containsKey(id)) {
            System.out.print("New food name: ");
            String name = sc.nextLine();
            System.out.print("New portions: ");
            int qty = readInt();
            System.out.print("New hours until it expires (from now): ");
            int hours = readInt();
            if (updateFood(id, name, qty, hours)) System.out.println("Updated: " + foods.get(id));
        } else if (id.startsWith("O") && orgs.containsKey(id)) {
            System.out.print("New name: ");
            String name = sc.nextLine();
            System.out.print("New storage capacity (portions): ");
            int cap = readInt();
            System.out.print("New people in need: ");
            int need = readInt();
            System.out.print("New urgency (1 to 5): ");
            int urg = readInt();
            if (updateOrganization(id, name, cap, need, urg)) System.out.println("Updated: " + orgs.get(id));
        } else {
            System.out.println("Not found.");
        }
    }

    // ---------- Ready-made test data (3 test scenarios from the proposal) ----------
    static void loadSampleData() {
        System.out.println("1 = Many donors, few organizations");
        System.out.println("2 = Limited storage");
        System.out.println("3 = Food about to expire");
        System.out.print("Choose scenario: ");
        int s = readInt();

        if (s < 1 || s > 3) {
            System.out.println("Wrong scenario. Choose 1, 2 or 3.");
            return;
        }

        Donor d1 = addDonor("Karachi Kitchen House", "Restaurant");
        Donor d2 = addDonor("Green Basket Supermarket", "Supermarket");
        Donor d3 = addDonor("Noor Wedding Hall", "Event Hall");

        if (s == 1) {
            addFood(d1.id, "Biryani", 40, 5);
            addFood(d2.id, "Bread", 60, 30);
            addFood(d3.id, "Rice", 80, 8);
            addFood(d3.id, "Curry", 50, 6);
            addOrganization("Al-Noor Welfare Trust", 100, 90, 5);
            addOrganization("Rehmat Children's Home", 100, 70, 3);
        } else if (s == 2) {
            addFood(d1.id, "Biryani", 50, 10);
            addFood(d2.id, "Bread", 50, 20);
            addOrganization("Small Shelter", 20, 60, 5);   // can store only 20
            addOrganization("Tiny Home", 10, 40, 4);        // can store only 10
            addOrganization("Big Kitchen", 100, 30, 2);
        } else {
            addFood(d1.id, "Salad", 30, -1);    // already expired
            addFood(d1.id, "Rolls", 30, 1);
            addFood(d2.id, "Milk", 30, 2);
            addFood(d3.id, "Rice", 30, 48);
            addOrganization("Al-Noor Welfare Trust", 100, 70, 4);
        }
        System.out.println("Sample data loaded. Choose 4 to run the allocation.");
    }

    // ---------- Reading input safely ----------
    // If the user types letters instead of a number, ask again (no crash)
    static int readInt() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Please type a number: ");
            }
        }
    }

    // =====================================================
    // PART 4: THE MENU (program starts here)
    // =====================================================
    public static void main(String[] args) {
        // Back end: open the SQLite database and load any saved data
        if (Database.open("foodbridge.db")) {
            if (Database.load()) System.out.println("Loaded saved data from foodbridge.db (hour " + now + ").");
            else System.out.println("Connected to a new database: foodbridge.db");
        }
        while (true) {
            System.out.println("\n=== FoodBridge === (hour " + now + ")");
            System.out.println("1 Add donor");
            System.out.println("2 Add food");
            System.out.println("3 Add organization");
            System.out.println("4 Run allocation");
            System.out.println("5 Show report");
            System.out.println("6 Find by ID");
            System.out.println("7 Load sample data");
            System.out.println("8 Move time forward");
            System.out.println("9 Delete by ID");
            System.out.println("10 Update by ID");
            System.out.println("11 Show database tables");
            System.out.println("12 Start fresh (clear saved data)");
            System.out.println("0 Exit");
            System.out.print("Choose: ");
            int choice = readInt();

            if (choice == 0) {
                break;
            } else if (choice == 1) {
                System.out.print("Donor name: ");
                String name = sc.nextLine();
                System.out.print("Type (Restaurant / Supermarket / Event Hall): ");
                String type = sc.nextLine();
                System.out.println("Added: " + addDonor(name, type));
            } else if (choice == 2) {
                System.out.print("Donor ID (like D1): ");
                String donorId = sc.nextLine().trim().toUpperCase();
                System.out.print("Food name: ");
                String name = sc.nextLine();
                System.out.print("Portions: ");
                int qty = readInt();
                System.out.print("Hours until it expires: ");
                int hours = readInt();
                FoodItem f = addFood(donorId, name, qty, hours);
                if (f != null) System.out.println("Added: " + f);
            } else if (choice == 3) {
                System.out.print("Organization name: ");
                String name = sc.nextLine();
                System.out.print("Storage capacity (portions): ");
                int cap = readInt();
                System.out.print("People in need: ");
                int need = readInt();
                System.out.print("Urgency (1 low to 5 very urgent): ");
                int urg = readInt();
                Organization o = addOrganization(name, cap, need, urg);
                if (o != null) System.out.println("Added: " + o);
            } else if (choice == 4) {
                runAllocation();
            } else if (choice == 5) {
                printReport();
            } else if (choice == 6) {
                findById();
            } else if (choice == 7) {
                loadSampleData();
            } else if (choice == 8) {
                System.out.print("Move forward by how many hours? ");
                int hours = readInt();
                if (hours < 0) {
                    System.out.println("Time cannot go backwards. Type 0 or more.");
                } else {
                    now = now + hours;
                    removeExpired();
                    System.out.println("Time moved. Expired food was removed.");
                }
            } else if (choice == 9) {
                deleteById();
            } else if (choice == 10) {
                updateById();
            } else if (choice == 11) {
                Database.showTables();
            } else if (choice == 12) {
                reset();
                System.out.println("All data cleared. The program starts again at hour 0.");
            } else {
                System.out.println("Wrong choice. Try again.");
            }
            if (choice != 6 && choice != 11) Database.save();   // write every change to the database
        }
        Database.save();
        Database.close();
        System.out.println("Goodbye!");
    }
}