import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * FoodBridge database (back end).
 *
 * Saves all FoodBridge data in an SQLite database file (foodbridge.db) using JDBC.
 * The data structures in Main (Min-Heap, Priority Queue, HashMaps) still do all the
 * work while the program runs. The database only SAVES the data after every menu
 * choice and LOADS it again when the program starts, so nothing is lost when the
 * program is closed.
 *
 * Needs the SQLite JDBC driver on the classpath: lib/sqlite-jdbc-3.41.2.2.jar
 * If the driver is missing, FoodBridge still runs normally, just without saving.
 *
 * Speed: save() and load() are O(n + m + d + a), where a = number of allocations.
 */
public class Database {

    static Connection conn = null;

    static final String[] TABLES = {"donors", "food_items", "organizations", "allocations", "expired_food", "settings"};

    // ---------- open the database file and create the tables ----------
    static boolean open(String file) {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:" + file);
            createTables();
            return true;
        } catch (ClassNotFoundException e) {
            System.out.println("SQLite driver not found (lib/sqlite-jdbc-3.41.2.2.jar). Running without a database.");
        } catch (SQLException e) {
            System.out.println("Could not open the database: " + e.getMessage() + ". Running without a database.");
        }
        conn = null;
        return false;
    }

    static void createTables() throws SQLException {
        try (Statement s = conn.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS donors ("
                    + " id TEXT PRIMARY KEY,"
                    + " name TEXT NOT NULL,"
                    + " type TEXT)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS food_items ("
                    + " id TEXT PRIMARY KEY,"
                    + " name TEXT NOT NULL,"
                    + " quantity INTEGER NOT NULL CHECK (quantity >= 0),"
                    + " expiry_hour INTEGER NOT NULL,"
                    + " donor_id TEXT REFERENCES donors(id),"
                    + " status TEXT CHECK (status IN ('AVAILABLE','FINISHED','EXPIRED','REMOVED')))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS organizations ("
                    + " id TEXT PRIMARY KEY,"
                    + " name TEXT NOT NULL,"
                    + " capacity INTEGER CHECK (capacity > 0),"
                    + " received INTEGER DEFAULT 0,"
                    + " need INTEGER CHECK (need >= 0),"
                    + " urgency INTEGER CHECK (urgency BETWEEN 1 AND 5))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS allocations ("
                    + " id TEXT PRIMARY KEY,"
                    + " seq INTEGER,"
                    + " food_id TEXT, food_name TEXT,"
                    + " org_id TEXT, org_name TEXT,"
                    + " quantity INTEGER,"
                    + " hour INTEGER)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS expired_food ("
                    + " food_id TEXT, name TEXT, quantity INTEGER, expiry_hour INTEGER, donor_id TEXT)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS settings ("
                    + " key TEXT PRIMARY KEY, value INTEGER)");
        }
    }

    // ---------- SAVE: write everything from the HashMaps and lists into the tables ----------
    static void save() {
        if (conn == null) return;
        try {
            conn.setAutoCommit(false);                    // one transaction: all or nothing
            try (Statement s = conn.createStatement()) {
                for (String t : TABLES) s.executeUpdate("DELETE FROM " + t);
            }
            try (PreparedStatement p = conn.prepareStatement("INSERT INTO donors VALUES (?,?,?)")) {
                for (Main.Donor d : Main.donors.values()) {
                    p.setString(1, d.id); p.setString(2, d.name); p.setString(3, d.type); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = conn.prepareStatement("INSERT INTO food_items VALUES (?,?,?,?,?,?)")) {
                for (Main.FoodItem f : Main.foods.values()) {
                    p.setString(1, f.id); p.setString(2, f.name); p.setInt(3, f.quantity);
                    p.setInt(4, f.expiryHour); p.setString(5, f.donorId); p.setString(6, f.status); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = conn.prepareStatement("INSERT INTO organizations VALUES (?,?,?,?,?,?)")) {
                for (Main.Organization o : Main.orgs.values()) {
                    p.setString(1, o.id); p.setString(2, o.name); p.setInt(3, o.capacity);
                    p.setInt(4, o.received); p.setInt(5, o.need); p.setInt(6, o.urgency); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = conn.prepareStatement("INSERT INTO allocations VALUES (?,?,?,?,?,?,?,?)")) {
                int seq = 1;
                for (Main.Allocation a : Main.allocationLog) {
                    p.setString(1, a.id); p.setInt(2, seq++); p.setString(3, a.foodId); p.setString(4, a.foodName);
                    p.setString(5, a.orgId); p.setString(6, a.orgName); p.setInt(7, a.quantity); p.setInt(8, a.hour); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = conn.prepareStatement("INSERT INTO expired_food VALUES (?,?,?,?,?)")) {
                for (Main.FoodItem f : Main.expiredFood) {
                    p.setString(1, f.id); p.setString(2, f.name); p.setInt(3, f.quantity);
                    p.setInt(4, f.expiryHour); p.setString(5, f.donorId); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = conn.prepareStatement("INSERT INTO settings VALUES (?,?)")) {
                String[] keys = {"now", "donorCount", "foodCount", "orgCount", "totalDonated", "totalGiven", "totalExpired", "totalDeleted"};
                int[] vals = {Main.now, Main.donorCount, Main.foodCount, Main.orgCount,
                        Main.totalDonated, Main.totalGiven, Main.totalExpired, Main.totalDeleted};
                for (int i = 0; i < keys.length; i++) { p.setString(1, keys[i]); p.setInt(2, vals[i]); p.addBatch(); }
                p.executeBatch();
            }
            conn.commit();
        } catch (SQLException e) {
            System.out.println("Could not save to the database: " + e.getMessage());
            try { conn.rollback(); } catch (SQLException ignored) { }
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException ignored) { }
        }
    }

    // ---------- LOAD: read the tables back into the HashMaps, heap and lists ----------
    // Returns true if saved data was found.
    static boolean load() {
        if (conn == null) return false;
        try (Statement s = conn.createStatement()) {
            ResultSet r = s.executeQuery("SELECT COUNT(*) FROM settings");
            if (!r.next() || r.getInt(1) == 0) return false;      // empty database

            Main.reset();
            r = s.executeQuery("SELECT key, value FROM settings");
            while (r.next()) {
                int v = r.getInt("value");
                switch (r.getString("key")) {
                    case "now": Main.now = v; break;
                    case "donorCount": Main.donorCount = v; break;
                    case "foodCount": Main.foodCount = v; break;
                    case "orgCount": Main.orgCount = v; break;
                    case "totalDonated": Main.totalDonated = v; break;
                    case "totalGiven": Main.totalGiven = v; break;
                    case "totalExpired": Main.totalExpired = v; break;
                    case "totalDeleted": Main.totalDeleted = v; break;
                    default: break;
                }
            }
            r = s.executeQuery("SELECT * FROM donors");
            while (r.next()) {
                Main.Donor d = new Main.Donor(r.getString("id"), r.getString("name"), r.getString("type"));
                Main.donors.put(d.id, d);
            }
            r = s.executeQuery("SELECT * FROM food_items");
            while (r.next()) {
                Main.FoodItem f = new Main.FoodItem(r.getString("id"), r.getString("name"), r.getInt("quantity"),
                        r.getInt("expiry_hour"), r.getString("donor_id"));
                f.status = r.getString("status");
                Main.foods.put(f.id, f);
                if (f.status.equals("AVAILABLE")) Main.foodHeap.insert(f);     // rebuild the Min-Heap
            }
            r = s.executeQuery("SELECT * FROM organizations");
            while (r.next()) {
                Main.Organization o = new Main.Organization(r.getString("id"), r.getString("name"),
                        r.getInt("capacity"), r.getInt("need"), r.getInt("urgency"));
                o.received = r.getInt("received");
                Main.orgs.put(o.id, o);
            }
            r = s.executeQuery("SELECT * FROM allocations ORDER BY seq");
            while (r.next()) {
                Main.allocationLog.add(new Main.Allocation(r.getString("id"), r.getString("food_id"), r.getString("food_name"),
                        r.getString("org_id"), r.getString("org_name"), r.getInt("quantity"), r.getInt("hour")));
            }
            r = s.executeQuery("SELECT * FROM expired_food");
            while (r.next()) {
                Main.FoodItem f = new Main.FoodItem(r.getString("food_id"), r.getString("name"), r.getInt("quantity"),
                        r.getInt("expiry_hour"), r.getString("donor_id"));
                f.status = "EXPIRED";
                Main.expiredFood.add(f);
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Could not load the database: " + e.getMessage());
            return false;
        }
    }

    // ---------- menu option 11: print every table ----------
    static void showTables() {
        if (conn == null) { System.out.println("No database is connected."); return; }
        System.out.println("\n===== DATABASE foodbridge.db =====");
        for (String t : TABLES) {
            try (Statement s = conn.createStatement()) {
                ResultSet c = s.executeQuery("SELECT COUNT(*) FROM " + t);
                int n = c.next() ? c.getInt(1) : 0;
                System.out.println(t + " (" + n + (n == 1 ? " row)" : " rows)"));
                ResultSet r = s.executeQuery("SELECT * FROM " + t + (t.equals("allocations") ? " ORDER BY seq" : ""));
                ResultSetMetaData md = r.getMetaData();
                StringBuilder head = new StringBuilder("  ");
                for (int i = 1; i <= md.getColumnCount(); i++) head.append(i > 1 ? " | " : "").append(md.getColumnName(i));
                if (n > 0) System.out.println(head);
                while (r.next()) {
                    StringBuilder row = new StringBuilder("  ");
                    for (int i = 1; i <= md.getColumnCount(); i++) row.append(i > 1 ? " | " : "").append(r.getString(i));
                    System.out.println(row);
                }
            } catch (SQLException e) {
                System.out.println("  could not read " + t + ": " + e.getMessage());
            }
        }
        System.out.println("==================================");
    }

    static void close() {
        if (conn == null) return;
        try { conn.close(); } catch (SQLException ignored) { }
        conn = null;
    }
}
