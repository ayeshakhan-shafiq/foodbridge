FoodBridge: An Expiry-Aware Surplus Food Donation Allocator
Saveez Ali (F25CSC020) · Ayesha Shafiq (F25CSC068) · DSA · BSCS Semester 3

FILES
  Main.java       the program: Min-Heap, Priority Queue, HashMaps, menu (options 0-12)
  Database.java   back end: saves everything in SQLite (foodbridge.db) using JDBC
  MainTest.java   11 JUnit 5 tests (10 for the rules, 1 for the database)
  lib/sqlite-jdbc-3.41.2.2.jar   SQLite JDBC driver (no installation needed)

RUN IN INTELLIJ IDEA
  1. Open this folder as a project.
  2. File > Project Structure > Modules > Dependencies > + > JARs > choose lib/sqlite-jdbc-3.41.2.2.jar
  3. Run Main. (For tests: add JUnit 5 when IntelliJ asks, then run MainTest.)

RUN FROM THE COMMAND LINE
  Windows:
    javac -cp lib\sqlite-jdbc-3.41.2.2.jar *.java
    java  -cp ".;lib\sqlite-jdbc-3.41.2.2.jar" Main
  Mac / Linux:
    javac -cp lib/sqlite-jdbc-3.41.2.2.jar *.java
    java  -cp ".:lib/sqlite-jdbc-3.41.2.2.jar" Main

HOW THE DATABASE WORKS
  - On start, the program opens foodbridge.db and loads any saved data.
  - After every menu choice, all data is saved (one transaction).
  - 11 Show database tables  prints every table and row.
  - 12 Start fresh           clears all data (hour 0).
  - If the driver jar is missing, the program still runs, just without saving.

QUICK DEMO
  7 -> 2 (Limited storage) -> 4 (Run allocation) -> 5 (Report) -> 11 (Database tables)
  Close the program, run it again, choose 5: the same report comes back from the database.
